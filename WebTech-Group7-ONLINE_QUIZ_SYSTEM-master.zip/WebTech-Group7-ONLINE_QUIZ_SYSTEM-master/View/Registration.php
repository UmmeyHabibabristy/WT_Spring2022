<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz System Registration Page</title>
</head>
<body>
        <h1>Register As:</h1>
        <hr/>
<table width="100%">
    <tr>
        <td><a href="../View/Student.php" text-><h2>Student</h2></a></td>
        <td><a href="../View/Teacher.php"><h2>Teacher</h2></a></td>
        <td><a href="../View/Admin.php"><h2>Admin</h2></a></td>
        <td><a href="../View/Guest.php"><h2>Guest</h2></a></td>
    </tr>
</table>

</body>
</html>